function Dashboard() {
  return (
    <div className="text-2xl font-semibold text-green-600">
      Página principal da dashboard 🚀
    </div>
  )
}

export default Dashboard
