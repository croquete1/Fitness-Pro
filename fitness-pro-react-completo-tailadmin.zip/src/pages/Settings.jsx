function Settings() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Definições</h2>
      <p className="text-sm text-gray-500">Aqui poderá alterar preferências da aplicação.</p>
    </div>
  )
}

export default Settings
