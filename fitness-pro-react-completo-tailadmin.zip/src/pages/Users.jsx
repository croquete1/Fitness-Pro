function Users() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Lista de Utilizadores</h2>
      <ul className="list-disc list-inside space-y-1">
        <li>Maria Silva</li>
        <li>João Costa</li>
        <li>Inês Fonseca</li>
      </ul>
    </div>
  )
}

export default Users
