import {useState, useRef} from 'react'
import {Link} from 'react-router-dom'
import DocFeatures from '../features/documentation/DocFeatures'

function ExternalPage(){


    return(
        <div className="">
            <DocFeatures />
        </div>
    )
}

export default ExternalPage